#include <30F2010.h>
#device ADC=10
#device ICSP=1
#fuses HS,NODEBUG,NOWDT,PR,CKSFSM
#use delay(crystal=20000000)


#use FIXED_IO( D_outputs=PIN_D1,PIN_D0 )
#use rs232(UART1, baud=9600, stream=UART_PORT1)

#define LED0    PIN_D0
#define LED1    PIN_D1
#define SW0   PIN_C13
#define SW1   PIN_C14

#define DELAY 500

