#include "board.h"

#define LCD_ENABLE_PIN  PIN_E5                                    
#define LCD_RS_PIN      PIN_E4                                    
#define LCD_RW_PIN      PIN_C14                                    
#define LCD_DATA4       PIN_E0                                    
#define LCD_DATA5       PIN_E1                                    
#define LCD_DATA6       PIN_E2                                    
#define LCD_DATA7       PIN_E3    

#include "lcd.c"

#define line_1() lcd_send_byte(0,0x80);
#define line_2() lcd_send_byte(0,0xC0);
#define line_3() lcd_send_byte(0,0x90);
#define line_4() lcd_send_byte(0,0xD0);
#define lcd_clear() lcd_putc('\f');

void main()
{
   
   long adc_value = 0;
   float analog=0;
   lcd_init();  
   setup_adc_ports(sAN4 | sAN5);
   setup_adc(ADC_CLOCK_INTERNAL | ADC_TAD_MUL_31);
   lcd_clear();
   printf(LCD_PUTC,"dsPIC30F2010 ADC");
   line_2();
   printf(LCD_PUTC,"and TC1604A-04");
   line_3();
   printf(LCD_PUTC,"LCD Interfacing");
   line_4()
   printf(LCD_PUTC,"With CCS PICC");
   delay_ms(5000);
   lcd_clear();
  
   while(TRUE)
   {
      //TODO: User Code    
      line_1();
      printf(LCD_PUTC,"ADC Reading(DEC)");
      set_adc_channel(4);
      delay_us(10);
      adc_value = read_adc();
      analog = (5.0*adc_value)/1023; 
      line_2();     
      printf(LCD_PUTC, "AN4: %4d %fV\n",adc_value, analog);    
      
      set_adc_channel(5);
      delay_us(10);
      adc_value = read_adc();
      analog = (5.0*adc_value)/1023; 
      line_3();
      printf(LCD_PUTC, "AN5: %4d %fV",adc_value, analog);
      analog = (500.0*adc_value)/1023; 
      line_4();
      printf(LCD_PUTC, "LM35DZ: %f%cC",analog,223);
      
      delay_ms(1000);
   }

}
