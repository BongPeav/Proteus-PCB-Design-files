#include <30F2010.h>
#device ICSP=1
#fuses HS,NODEBUG,NOWDT,PR,CKSFSM
#use delay(crystal=20000000)

#define LED0 PIN_D0
#define LED1 PIN_D1
#define SW0	PIN_C13
#define SW1	PIN_C14

#define DELAY 500

