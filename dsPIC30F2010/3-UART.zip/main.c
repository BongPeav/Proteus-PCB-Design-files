#include "board.h"

#use rs232(UART1, baud=9600, stream=UART_PORT1)

void main()
{
   long cnt=0;
   printf("HELLO WORLD!\n\r");
   printf("Saturady 13 September 2025\n\r");
   printf("dsPIC30F2010 DIY Prototype Board.\n\r");
   printf("UART To RS-232 Demo Program\n\r");
   while(TRUE)
   {
      //TODO: User Code
      printf("Time In Seconds: %Lu \n\r",cnt);
      output_toggle(LED0);
      cnt++;
      delay_ms(1000);
   }

}
