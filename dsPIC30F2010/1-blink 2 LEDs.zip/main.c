#include "board.h"


void main()
{

   //Example blinking LED program
   while(true)
   {
      output_low(LED0);
      output_high(LED1);
      delay_ms(DELAY);
      output_high(LED0);
      output_low(LED1);
      delay_ms(DELAY);
   }

}
