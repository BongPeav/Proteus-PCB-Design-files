#include <30F2010.h>
#device ICSP=1
#fuses HS,NODEBUG,NOWDT,PR,CKSFSM
#use delay(crystal=20000000)

#define LED0 PIN_D0
#define LED1 PIN_D1

#define DELAY 500

