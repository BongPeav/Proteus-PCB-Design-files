#include <30F2010.h>
#device ICSP=1
#use delay(crystal=20000000)

#FUSES NOWDT                    
//No Watch Dog Timer
#FUSES CKSFSM                   
//Clock Switching is enabled, fail Safe clock monitor is enabled


#use FIXED_IO( D_outputs=PIN_D1,PIN_D0 )

#define CN1   PIN_C13
#define CN0   PIN_C14
#define LED1   PIN_D0
#define LED2   PIN_D1



