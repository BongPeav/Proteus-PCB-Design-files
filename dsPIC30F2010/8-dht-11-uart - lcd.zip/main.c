#include "board.h"

#define PIN_DHT11_DATA  PIN_B0
#include <dht11.c>

                                 
#define LCD_RS_PIN      PIN_E4   
#define LCD_RW_PIN      PIN_E5
#define LCD_ENABLE_PIN  PIN_E5   
                                  
#define LCD_DATA4       PIN_E0                                    
#define LCD_DATA5       PIN_E1                                    
#define LCD_DATA6       PIN_E2                                    
#define LCD_DATA7       PIN_E3    

#include "lcd.c"

#define lcd_clear() lcd_putc('\f')
#define lcd_home()  lcd_putc('\a')
/*For 16x4 LCD Only*/
#define line_1() lcd_send_byte(0,0x80);
#define line_2() lcd_send_byte(0,0xC0);
#define line_3() lcd_send_byte(0,0x90);
#define line_4() lcd_send_byte(0,0xD0);


void main(){
   unsigned int8 relativeHumidity;
   unsigned int8 tempC;
   printf("\n\rdsPIC30F2010 Prototype Board.");
   printf("\n\rFriday 26 September 2025");
   printf("\n\rDHT-11 Humidity Sensor Example\n\r");
   printf("\r\n\r\dht-11.c - DHT11 example starting\r\n\r\n");  
   dht11_init();
   lcd_init();
   printf(LCD_PUTC,"dsPIC30F2010 LCD");
   line_2();
   printf(LCD_PUTC,"DHT-11 Sensor");
   line_3();
   printf(LCD_PUTC,"Example Using");
   line_4();
   printf(LCD_PUTC,"CCS PICC v5.119");
   delay_ms(5000);
   lcd_clear();
   while(1){       
      dht11_read(&relativeHumidity, &tempC);     
      printf("HUMIDITY=%03u%%, TEMPERATURE=%02uC\r\n", relativeHumidity, tempC);
      lcd_home();
      printf(LCD_PUTC,"  DHT-11 Sensor");
      line_2();
      printf(LCD_PUTC,"    Reading:");
      line_3();
      printf(LCD_PUTC,"Humidity: %03u%%",relativeHumidity);
      line_4();
      printf(LCD_PUTC,"Temperature:%02u%cC",tempC,0xDF);
      delay_ms(1000); 
   }
}
