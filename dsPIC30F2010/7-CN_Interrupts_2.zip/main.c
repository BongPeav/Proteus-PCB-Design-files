#include <main.h>

/*CN Pull Up Enable Register*/
#byte CNPU1=0x0C4;
#bit CN0PU=CNPU1.0;
#bit CN1PU=CNPU1.1;
/*CN Interrupt Enable Register*/
#byte CNIEN1=0x0C0;
#bit CN0EN=CNIEN1.0;
#bit CN1EN=CNIEN1.1;

/*Interrupt Service Routine for CN Interrupt*/
#INT_CNI
void  cni_isr(void) 
{  
    if(!input(CN0)) output_toggle(LED2);
    if(!input(CN1)) output_toggle(LED1);
    clear_interrupt(INT_CNI);
}


void main()
{
   /*PortC As Inputs*/
   set_tris_c(0xFFFF);
   /*Turn On CN0 PullUp and CN0 and CN1 Interrupt*/
   CN0PU=1;
   CN0EN=1;
   CN1PU=1;
   CN1EN=1;
   /*Enable Interrupt*/
   //enable_interrupts(INTR_CN_PIN|PIN_C13);
   //enable_interrupts(INTR_CN_PIN|PIN_C14);
   enable_interrupts(INT_CNI);
   enable_interrupts(INTR_GLOBAL);
   clear_interrupt(INT_CNI);
   while(TRUE)
   {
      //TODO: User Code      
   }

}
