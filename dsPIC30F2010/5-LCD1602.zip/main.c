#include "board.h"

#define LCD_ENABLE_PIN  PIN_E5                                    
#define LCD_RS_PIN      PIN_E4                                    
#define LCD_RW_PIN      PIN_C14                                    
#define LCD_DATA4       PIN_E0                                    
#define LCD_DATA5       PIN_E1                                    
#define LCD_DATA6       PIN_E2                                    
#define LCD_DATA7       PIN_E3    
#include <LCD.C>


void main()
{
   long run_time=0;
   lcd_init();
   lcd_putc("\f");
   printf(LCD_PUTC,"HELLO WORLD!\n");
   printf(LCD_PUTC,"dsPIC30F2010 LCD");
   delay_ms(5000);
   lcd_putc("\f");
   printf(LCD_PUTC,"CCS PICC\n");
   printf(LCD_PUTC,"Example....");
   delay_ms(5000);
   lcd_putc('\f');
   
   while(TRUE)
   {
      //TODO: User Code
      lcd_putc('\a');
      printf(LCD_PUTC,"ON TIME: \n%Lu Seconds",run_time);
      run_time++;
      delay_ms(1000);
   }

}
