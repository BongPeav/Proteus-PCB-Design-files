#include "board.h"

#define PIN_DHT11_DATA  PIN_B0
#include <dht11.c>

void main(){
   unsigned int8 relativeHumidity;
   unsigned int8 tempC;
   printf("\n\rdsPIC30F2010 Prototype Board.");
   printf("\n\rWednesday 25 September 2025");
   printf("\n\rDHT-11 Humidity Sensor Example\n\r");
   printf("\r\n\r\dht-11.c - DHT11 example starting\r\n\r\n");  
   dht11_init();
   delay_ms(1000);
   while(1){       
      dht11_read(&relativeHumidity, &tempC);     
      printf("HUMIDITY=%03u%%, TEMPERATURE=%02uC\r\n", relativeHumidity, tempC);
      delay_ms(2000); 
   }
}
