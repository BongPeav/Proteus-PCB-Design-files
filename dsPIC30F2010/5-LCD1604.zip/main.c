#include "board.h"

#define LCD_ENABLE_PIN  PIN_E5                                    
#define LCD_RS_PIN      PIN_E4                                    
#define LCD_RW_PIN      PIN_C14                                    
#define LCD_DATA4       PIN_E0                                    
#define LCD_DATA5       PIN_E1                                    
#define LCD_DATA6       PIN_E2                                    
#define LCD_DATA7       PIN_E3    

#include <LCD.C>

#define line_1() lcd_send_byte(0,0x80);
#define line_2() lcd_send_byte(0,0xC0);
#define line_3() lcd_send_byte(0,0x90);
#define line_4() lcd_send_byte(0,0xD0);
#define lcd_clear() lcd_putc('\f');

void main()
{
   long run_time=0;
   lcd_init();  
   lcd_clear();
   printf(LCD_PUTC,"dsPIC30F2010 LCD\n");
   printf(LCD_PUTC,"20x4 Characters");
   
   line_3();
   printf(LCD_PUTC,"Example With");
   line_4()
   printf(LCD_PUTC,"CCS PICC 5.119");
   delay_ms(5000);
   lcd_putc('\f');
   
   while(TRUE)
   {
      //TODO: User Code
      lcd_putc('\a');
      printf(LCD_PUTC,"ON TIME: \n%Lu Seconds",run_time);
      run_time++;
      delay_ms(1000);
   }

}
