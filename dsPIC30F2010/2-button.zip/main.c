#include "board.h"


void main()
{

   set_pullup(TRUE,PIN_C13);
   set_pullup(TRUE,PIN_C14);


   while(TRUE)
   {
      //TODO: User Code
      if(input(SW0)==0){
         output_toggle(LED0);
         delay_ms(500);
      }
      if(input(SW1)==0){
         output_toggle(LED1);
         delay_ms(500);
      }
   }

}
