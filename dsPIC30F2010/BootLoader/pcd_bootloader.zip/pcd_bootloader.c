
/*CCS PICC Compiler version 5.049*/
#include <30F2010.h>
#fuses HS,NODEBUG,NOWDT,PR,CKSFSM
#use delay(clock=20000000)
#use rs232(BAUD=9600,UART1)

#define PUSH_BUTTON PIN_C14
#define BOOT_LED PIN_D0

#define _bootloader
//#define BOOTLOADER_MODE2X

#include <pcd_bootloader.h>
#include <loader_pcd.c>

#org APPLICATION_START
void application(void)
{
   while(TRUE);
}

void main(void)
{
   output_c(0);
   output_d(0);
   set_tris_d(0);
   set_tris_c(1<<14);
   //set_pullup(TRUE,PUSH_BUTTON); 
   output_high(PUSH_BUTTON);
   if(!input(PUSH_BUTTON))
   {      
      output_high(BOOT_LED);
      // Let the user know it is ready to accept a download
      printf("\r\nWaiting for download...");
      // Load the program
      load_program();
   }
  
   output_low(BOOT_LED);
   application();
   
   while(1);
   
}

#int_default
void isr(void)
{
   jump_to_isr(LOADER_END+5);
}

