
/*CCS PICC Compiler version 5.049*/
#include <30F2010.h>
#fuses HS,NODEBUG,NOWDT,PR,CKSFSM
#use delay(clock=20M)
#use rs232(UART1,BAUD=9600)

//#define BOOTLOADER_MODE2X

//This is a necessary include file.  It reserves space so that the
//bootloader is not overwritten.
#include <pcd_bootloader.h>

#define PIN_DS18B20_DATA PIN_B0
#include "ds18b20.c"

#define LCD_RS_PIN      PIN_E4   
#define LCD_RW_PIN      PIN_E5
#define LCD_ENABLE_PIN  PIN_E5   
                                  
#define LCD_DATA4       PIN_E0                                    
#define LCD_DATA5       PIN_E1                                    
#define LCD_DATA6       PIN_E2                                    
#define LCD_DATA7       PIN_E3    

#include "lcd.c"

#define lcd_clear() lcd_putc('\f')
#define lcd_home()  lcd_putc('\a')
/*For 16x4 LCD Only*/
#define line_1() lcd_send_byte(0,0x80);
#define line_2() lcd_send_byte(0,0xC0);
#define line_3() lcd_send_byte(0,0x90);
#define line_4() lcd_send_byte(0,0xD0);

print_message(void){
   delay_ms(10);
   printf("\rCCS PICC v5.049 PCD BOOTLOADER\n\r");
}

void main(){
   print_message();
   signed int16 val;
   
   printf("\n\rdsPIC30F2010 Prototype Board.");
   printf("\n\rSaturday 26th September 2025");
   printf("\n\rds18b20 Humidity Sensor Example\n\r");
   printf("\r\n\r\ds18b20.c - DHT11 example starting\r\n\r\n");  
   ds18b20_init();
   lcd_init();
   
   printf(LCD_PUTC,"dsPIC30F2010 LCD");
   line_2();
   printf(LCD_PUTC,"ds18b20 Sensor");
   line_3();
   printf(LCD_PUTC,"PCD BootLoader");
   line_4();
   printf(LCD_PUTC,"CCS PICC v5.049");
   delay_ms(5000);
   lcd_clear();
   
   while(1){       
      ds18b20_read(&val);      
      printf("temperature = %ldC\r\n", val/(signed int16)16);
      lcd_home();
      printf(LCD_PUTC," ds18b20 Sensor");
      line_2();
      printf(LCD_PUTC,"  Temperature");
      line_3();
      printf(LCD_PUTC,"     %ld%cC",val/(signed int16)16,0xDF);
      line_4();
      printf(LCD_PUTC," and %f%cF",1.8*(val/(signed int16)16)+32,0xDF);
      delay_ms(1000);  
   }
}
