

/*CCS PICC Compiler version 5.049*/
#include <30F2010.h>
#fuses HS,NODEBUG,NOWDT,PR,CKSFSM
#use delay(clock=20M)
#use rs232(UART1,BAUD=9600)

//#define BOOTLOADER_MODE2X

//This is a necessary include file.  It reserves space so that the
//bootloader is not overwritten.
#include <pcd_bootloader.h>

#define LED_0 PIN_D1

print_message(void){
   delay_ms(10);
   printf("\rCCS PICC v5.049 PCD BOOTLOADER\n\r");
}

void main()
{ 
   print_message();
   unsigned int16 counter=0;
   output_d(0);
   set_tris_d(0);
   
   
   while(TRUE)
   {
      output_toggle(LED_0);
      printf("Counter Variable: %Lu\n\r",counter);
      counter++;
      delay_ms(1000);
   }
}
