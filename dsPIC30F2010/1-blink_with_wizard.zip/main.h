#include <30F2010.h>
#device ICSP=1
#use delay(crystal=20000000)

#FUSES NOWDT                 	//No Watch Dog Timer
#FUSES CKSFSM                	//Clock Switching is enabled, fail Safe clock monitor is enabled


#define LED PIN_D0
#define DELAY 1000

