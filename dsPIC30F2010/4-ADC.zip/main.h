#include <30F2010.h>
#device ADC=10
#device ICSP=1
#use delay(crystal=10000000)

#FUSES NOWDT                 	//No Watch Dog Timer
#FUSES CKSFSM                	//Clock Switching is enabled, fail Safe clock monitor is enabled


#use FIXED_IO( C_outputs=PIN_C14,PIN_C13 )
#use FIXED_IO( D_outputs=PIN_D1,PIN_D0 )

#define SW4	PIN_C13
#define SW5	PIN_C14
#define LED0	PIN_D0
#define LED1	PIN_D1

#use rs232(UART1, baud=9600, stream=UART_PORT1)


