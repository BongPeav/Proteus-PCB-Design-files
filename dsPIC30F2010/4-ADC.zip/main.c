#include "board.h"

void main()
{
   unsigned int16 adc_value = 0;
   float analog=0;
   set_pullup(TRUE,PIN_C13);
   set_pullup(TRUE,PIN_C14);
   output_high(LED0);
   setup_adc_ports(sAN4 | sAN5);
   setup_adc(ADC_CLOCK_INTERNAL | ADC_TAD_MUL_31);
   
   printf("dsPIC30F2010 CCS PICC ADC and UART Example\n\r");
   printf("Using dsPIC30F2010 Prototype Board\n\r");
   printf("Wednesday 10-Sept-2025\n\r");
   printf("**************************************************\n\r");
   delay_ms(100);
   
   while(TRUE)
   {
      //TODO: User Code
      set_adc_channel(4);
      delay_us(50);
      adc_value = read_adc();
      analog = (5.0*adc_value)/1023; 
      printf("AN4: %4d Decimal %f Volts\n\r",adc_value, analog);    
      output_toggle(LED0);
      
      set_adc_channel(5);
      delay_us(50);
      adc_value = read_adc();
      analog = (500.0*adc_value)/1023; 
      printf("AN5: %4d Decimal %f Degree Celsius\n\r",adc_value, analog);
      printf("**************************************************\n\r");
      output_toggle(LED1);
      delay_ms(1000);
   }

}
