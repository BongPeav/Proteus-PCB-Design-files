#include "board.h"

#use pwm(OC1,TIMER=2,FREQUENCY=10000,STREAM=_1,DUTY=0)
#use pwm(OC2,TIMER=3,FREQUENCY=10000,STREAM=_2,DUTY=0)

void main()
{
   long adc_value = 0;
   int oc2_count=0;
   float duty_cycle = 0;
   set_pullup(TRUE,PIN_C13);
   set_pullup(TRUE,PIN_C14);  
   setup_adc_ports(sAN4);
   setup_adc(ADC_CLOCK_INTERNAL | ADC_TAD_MUL_31);

   while(TRUE)
   {
      //TODO: User Code  
      set_adc_channel(4);
      delay_us(10);
      adc_value = read_adc();
      duty_cycle = (1000.0*adc_value)/1023;
      pwm_set_duty(_1,(int)duty_cycle);
      
      if(input(SW0)==0){
         if(oc2_count<1000) oc2_count+=100;
         pwm_set_duty(_2,oc2_count);
         delay_ms(250);
      }
      if(input(SW1)==0){
         if(oc2_count>0) oc2_count-=100;
         pwm_set_duty(_2,oc2_count);
         delay_ms(250);
      }     
   }

}
