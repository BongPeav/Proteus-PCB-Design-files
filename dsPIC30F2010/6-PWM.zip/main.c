#include "board.h"

#use pwm(OC1,TIMER=2,FREQUENCY=10000,STREAM=_1,DUTY=50)
void main()
{
   long adc_value = 0;
   float duty_cycle = 0;
   setup_adc_ports(sAN4);
   setup_adc(ADC_CLOCK_INTERNAL | ADC_TAD_MUL_31);


   while(TRUE)
   {
      //TODO: User Code
      set_adc_channel(4);
      delay_us(10);
      adc_value = read_adc();
      duty_cycle = (1000.0*adc_value)/1023;
      pwm_set_duty(_1,(int)duty_cycle);
      //pwm_set_duty_percent(_1,(int)duty_cycle);
      delay_ms(100);
   }

}
