#include <main.h>

unsigned int16 count_1_ms=0, count_100_ms=0;

TICK_TYPE GetTickDifference(TICK_TYPE currTick, TICK_TYPE prevTick)
{
   return(currTick-prevTick);
}

void timer_1_tick(void)
{
   //TODO: User Code   
   count_1_ms++;
   if(count_1_ms>=100) {
      output_toggle(LED2);
      count_1_ms=0;
      count_100_ms++;
   }
   if(count_100_ms>=5){
      output_toggle(LED1);
      count_100_ms=0;
   }
}


void main()
{

   TICK_TYPE CurrentTick,PreviousTick;



   //Example program using Tick Timer
   CurrentTick = PreviousTick = get_ticks();

   while(TRUE)
   {
      CurrentTick = get_ticks();

      if(GetTickDifference(CurrentTick, PreviousTick) >= ((TICK_TYPE)TICKS_PER_SECOND*1)/1000)
      {
         timer_1_tick();
         PreviousTick = CurrentTick;
      }

      //TODO: User Code
   }

}
