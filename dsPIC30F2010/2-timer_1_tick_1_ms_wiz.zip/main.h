#include <30F2010.h>
#device ICSP=1
#use delay(crystal=20000000)

#FUSES NOWDT                 	//No Watch Dog Timer
#FUSES CKSFSM                	//Clock Switching is enabled, fail Safe clock monitor is enabled


#use FIXED_IO( D_outputs=PIN_D1,PIN_D0 )

#define LED1	PIN_D0
#define LED2	PIN_D1


#use timer(timer=1,tick=100us,bits=32,NOISR)

#define TICK_TYPE unsigned int32

