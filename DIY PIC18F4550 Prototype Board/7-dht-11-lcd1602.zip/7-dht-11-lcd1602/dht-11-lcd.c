
#include <18F4550.h>
#DEVICE ADC = 10
#fuses HSPLL,NOWDT,NOPROTECT,NOLVP,NODEBUG,USBDIV,PLL5,CPUDIV1,VREGEN
#use delay(clock=48000000)
#use rs232(baud=9600,xmit=PIN_C6,rcv=PIN_C7)

#define LCD_ENABLE_PIN  PIN_D3                                    
#define LCD_RS_PIN      PIN_D2                                    
                             
#define LCD_DATA4       PIN_D4                                    
#define LCD_DATA5       PIN_D5                                    
#define LCD_DATA6       PIN_D6                                    
#define LCD_DATA7       PIN_D7

#include "lcd.c"
#include <dht11.c>

#define lcd_clear() lcd_putc('\f')

void main(){
   unsigned int8 relativeHumidity;
   unsigned int8 tempC;
   printf("\n\rPIC18F4550 DIY USB Prototype Board.");
   printf("\n\rWednesday 23 September 2025");
   printf("\n\rDHT-11 Humidity Sensor Example\n\r");
   printf("\r\n\r\dht-11.c - DHT11 example starting\r\n\r\n");  
   dht11_init();
   lcd_init();
   lcd_clear();
   printf(LCD_PUTC,"PIC18F4550 LCD\nDHT-11 Example");
   delay_ms(5000);
   lcd_clear();
  
   while(1){
         
      dht11_read(&relativeHumidity, &tempC);     
      printf("HUMIDITY=%03u%%, TEMPERATURE=%02uC\r\n", relativeHumidity, tempC);
      lcd_gotoxy(1,1);
      printf(LCD_PUTC, "Humidity: %03u%%\nTemperature:%02u%cC",relativeHumidity,tempC,223);
      delay_ms(2000);  
   }
}
