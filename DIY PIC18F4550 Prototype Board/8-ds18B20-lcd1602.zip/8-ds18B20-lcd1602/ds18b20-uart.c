
#include <18F4550.h>
#DEVICE ADC = 10
#fuses HSPLL,NOWDT,NOPROTECT,NOLVP,NODEBUG,USBDIV,PLL5,CPUDIV1,VREGEN
#use delay(clock=48000000)
#use rs232(baud=9600,xmit=PIN_C6,rcv=PIN_C7)

#define PIN_DS18B20_DATA PIN_B4
#include <ds18b20.c>

#define LCD_ENABLE_PIN  PIN_D3                                    
#define LCD_RS_PIN      PIN_D2                                    
                             
#define LCD_DATA4       PIN_D4                                    
#define LCD_DATA5       PIN_D5                                    
#define LCD_DATA6       PIN_D6                                    
#define LCD_DATA7       PIN_D7

#include "lcd.c"
#define lcd_clear() lcd_putc('\f')

void main(){
   signed int16 val;
   printf("\n\rPIC18F4550 DIY USB Prototype Board.");
   printf("\n\rWednesday 03 September 2025");
   printf("\n\rds18B20 one-wire Temperature Sensor Example\n\r");
   printf("\r\n\r\ds18b20.c - ds18B20 example starting\r\n\r\n");  
   ds18b20_init();
   lcd_init();
   lcd_clear();
   printf(LCD_PUTC,"PIC18F4550 LCD\nds18b20 Example");
   delay_ms(5000);
   lcd_clear();
   
   while(1){       
      ds18b20_read(&val);      
      printf("temperature = %ldC\r\n", val/(signed int16)16);
      lcd_gotoxy(1,1);
      printf(LCD_PUTC, "Temperature:\n%ld%cC",val/(signed int16)16,223);
      delay_ms(2000);  
   }
}
